#### -- Packrat Autoloader (version 0.4.8-24) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
